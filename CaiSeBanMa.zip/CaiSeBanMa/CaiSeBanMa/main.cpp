#include "caisebanma.h"
#include <QtGui/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	CaiSeBanMa w;
	w.show();
	return a.exec();
}
